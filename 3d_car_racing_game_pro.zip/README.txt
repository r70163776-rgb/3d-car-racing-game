3D Car Racing Game - Pro (Vercel / WebView ready)
-----------------------------------------------
Files in this ZIP:
 - index.html    -> Single-file HTML5 game (mobile friendly)
How to deploy:
 1. Unzip and upload the folder contents to Vercel (or GitHub Pages / Netlify).
 2. After deploy, you'll get a public URL like https://your-project.vercel.app
 3. In Sketchware WebView: webview1.loadUrl("https://your-project.vercel.app")
Notes:
 - This file uses WebAudio (generates engine sound programmatically).
 - No external assets required.
 - If you want Ad integration (Monetag or AdSense), add JS code in index.html where you want ads.